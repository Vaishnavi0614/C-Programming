#include<stdio.h>

int main()
{
    printf("Its my Second Program");
    return 0;
}
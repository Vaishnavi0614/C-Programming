
int no = 10;

no++;
i = ++no;
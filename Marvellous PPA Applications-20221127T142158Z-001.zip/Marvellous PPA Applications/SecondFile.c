int B = 10;             // Global variable

static int C = 10;      // Global statc variable
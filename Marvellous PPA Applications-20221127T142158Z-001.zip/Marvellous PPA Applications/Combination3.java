// Case 3
class Demo 
{
}
class Hello extends Demo
{
}
class Marvellous extends Demo
{
}
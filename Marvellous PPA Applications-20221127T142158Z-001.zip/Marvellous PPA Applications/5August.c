#include<stdio.h>

int main()
{
    printf("First C Program\n");

    return 0;
}
#include<stdio.h>

int main()
{
    const int no1 = 11;
    const int no2;

    return 0;
}
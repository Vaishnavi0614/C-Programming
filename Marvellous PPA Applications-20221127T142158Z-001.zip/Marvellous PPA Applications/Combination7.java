// Case 7
interface Demo 
{
}
class Hello 
{
}
class Marvellous extends Hello implements Demo
{
}

class A
{
     
}

class B extends A
{

}

class C extends A
{

}

class Hierarchal
{
     public static void main(String p[])
     {

     }
}
#include<stdio.h>

int main()
{

    printf("Jay Ganesh..\n");
    
    printf("Jay Ganesh..\n");
    
    printf("Jay Ganesh..\n");
    
    printf("Jay Ganesh..\n");
    
    printf("Jay Ganesh..\n");
    
    return 0;
}
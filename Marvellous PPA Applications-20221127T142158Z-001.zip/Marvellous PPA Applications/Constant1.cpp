#include<iostream>
using namespace std;

int main()
{
    const int no1 = 11;     // Allowed in C & C++
    const int no2;          // Allowed in C but not allowed in C++

    int x;
    
    return 0;
}